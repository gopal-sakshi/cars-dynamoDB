exports.handler = async (event) => {
    let body = JSON.parse(event.body)
    const product = body.num1 * body.num2;
    const response = {
        statusCode: 200,
        body: "The product of " + body.num1 + " and " + body.num2 + " is " + product,
    };
    return response;
};

/* 
    zip function23.zip sns_lambda23.js

    awslocal lambda create-function \
        --function-name localstack-lambda-url-example \
        --runtime nodejs18.x \
        --zip-file fileb://function.zip \
        --handler index.handler \
        --role arn:aws:iam::000000000000:role/lambda-role
        
*/